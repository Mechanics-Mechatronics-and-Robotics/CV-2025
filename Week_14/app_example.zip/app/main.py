from fastapi import FastAPI
from pydantic import BaseModel
from transformers import pipeline

# You can check any other model in the Hugging Face Hub
pipe = pipeline(task="text-classification", 
		model="distilbert/distilbert-base-uncased-finetuned-sst-2-english")

# We define the app
app = FastAPI()

class SentimentResponse(BaseModel):
    text: str
    sentiment_label: str
    sentiment_score: float

@app.get("/")
async def home():
  return {"message": "Testing machine learning service"}

# Now we define that we accept post requests
@app.get("/sentiment")
def get_response(text: str):
   response_model = pipe(text)
   label = response_model[0]["label"]
   score = response_model[0]["score"]
   response = SentimentResponse(
       text=text,
       sentiment_label=label,
       sentiment_score=score,)
   return response
